#include <cppunit/config/SourcePrefix.h>

#include "Admin.h"
#include "testAdmin.h"
#include <iostream>
#include <string>
using namespace std;
void 
AdminTest::setUp()
{
}


void 
AdminTest::tearDown()
{
}
CPPUNIT_TEST_SUITE_REGISTRATION( AdminTest );

void AdminTest::testAddMember(){
	Admin admin("admin1","adminpass");
	vector<ClubMember> c;
	vector<ClubMember>::iterator ite;
	//add a member with id : test01
	// name: I am test
	// email: test@test.com
	//phone :12345
	// pass : test
	// ranking : 10
	cout << "Enter the following information :test01,test,I am test,test@test.com,12345,10 "<< endl;
	admin.addMember(c);
	ite = c.begin();
	CPPUNIT_ASSERT((*ite).getID() == "test01");
	CPPUNIT_ASSERT((*ite).getName() == "I am test");
	CPPUNIT_ASSERT((*ite).getEmail() == "test@test.com");
	CPPUNIT_ASSERT((*ite).getPhone() == "12345");
	CPPUNIT_ASSERT((*ite).getPass() == "test");
	CPPUNIT_ASSERT_EQUAL(10,(*ite).getRanking());
}
void AdminTest::testDeleteMember(){
		Admin admin("admin1","adminpass");
		vector<ClubMember> c;
			// add a dump member into ClubMember vector with ID test01
		  // after delete with ID it should be empty
		ClubMember dump("test01","test","I am test","test@test.com","12345",10);
		c.push_back(dump);
		cout << "Enter the following information:test01,y " << endl;
		admin.deleteMember(c);
		int d;
		d = c.empty();
		CPPUNIT_ASSERT_EQUAL(1,d);
}