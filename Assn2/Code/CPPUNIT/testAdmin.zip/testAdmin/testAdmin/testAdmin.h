#ifndef TestAdmin_h
#define TestAdmin_h
#include <cppunit/extensions/HelperMacros.h>

class AdminTest : public CPPUNIT_NS::TestFixture // Note 2 
{ 
CPPUNIT_TEST_SUITE( AdminTest ); // Note 3 
CPPUNIT_TEST( testAddMember );
CPPUNIT_TEST( testDeleteMember );
CPPUNIT_TEST_SUITE_END();

public:
void setUp();
void tearDown();

// method to add member
void testAddMember();
// method to test delete Member;
void testDeleteMember();
};
#endif