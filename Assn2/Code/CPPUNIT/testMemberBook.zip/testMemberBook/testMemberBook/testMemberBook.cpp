#include <cppunit/config/SourcePrefix.h>

#include "ClubMember.h"
#include "testMemberBook.h"
#include <iostream>
#include <string>
using namespace std;
void 
BookingTest::setUp()
{
}


void 
BookingTest::tearDown()
{
}
CPPUNIT_TEST_SUITE_REGISTRATION( BookingTest );

void BookingTest::testBooking(){
	ClubMember dump("test01","test","I am test","test@test.com","12345",10);
	vector<BookedFaci> testBook;
	vector<Facilities> testFac;
	vector<BookedFaci>::iterator ite;
	Facilities dumpFac("BAS032","Basket Ball playground","Available",4.4,5,3);
	testFac.push_back(dumpFac);
	cout << "Enter the following information :BAS032,03/02/2016,12:32,3"<< endl;
	dump.BookFacility(testFac,testBook);
	ite = testBook.begin();
	CPPUNIT_ASSERT((*ite).getFac() == "BAS032");
	CPPUNIT_ASSERT((*ite).getMem() == "test01");
	CPPUNIT_ASSERT((*ite).getDate() == "03/02/2016");
	CPPUNIT_ASSERT((*ite).getTime() == "12:32");
	CPPUNIT_ASSERT_EQUAL(3,(*ite).getDur());
}
