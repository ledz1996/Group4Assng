#ifndef TestMem_h
#define TestMem_h
#include <cppunit/extensions/HelperMacros.h>

class BookingTest : public CPPUNIT_NS::TestFixture // Note 2 
{ 
CPPUNIT_TEST_SUITE( BookingTest ); // Note 3 
CPPUNIT_TEST( testBooking );
CPPUNIT_TEST_SUITE_END();

public:
void setUp();
void tearDown();

// method to book a facility
void testBooking();

};
#endif